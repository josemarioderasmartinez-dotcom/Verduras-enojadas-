# Verduras Furiosas — proyecto Android

Proyecto Android Studio que envuelve el juego HTML5 local en un WebView. Se fuerza orientación horizontal y no necesita internet para jugar.

## Generar el APK en Android Studio
1. Instala Android Studio en una computadora (Windows, macOS o Linux) y abre esta carpeta como proyecto.
2. Acepta la instalación de Android SDK/Build Tools si Android Studio la solicita.
3. Espera a que termine **Gradle Sync**.
4. Para un APK de prueba: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Pulsa **locate** en la notificación de compilación. El archivo suele quedar en `app/build/outputs/apk/debug/app-debug.apk`.
6. Pasa ese APK al teléfono Android, ábrelo y permite instalar aplicaciones desde esa fuente si el sistema lo pide.

## APK de publicación
Usa **Build > Generate Signed Bundle / APK > APK**, crea una clave de firma y guarda una copia segura. No compartas la clave privada.

## Nota
El proyecto fuente se proporciona; este entorno no ha compilado ni probado el APK. El primer APK se debe probar en el teléfono. El juego está diseñado para jugarse en horizontal.
